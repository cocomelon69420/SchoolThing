function love.load()
    loadBuilding()
    loadBuilding2()
end

------------------------------------------Load--------------------------

function loadBuilding()
    building = love.graphics.newImage("assets/building.png")
    building_x = math.random(0,800) --- random position
    building_y = 0
    building_w = building:getWidth()
    building_h = building:getHeight()
    buildingScale_X = 1
    buildingScale_Y = 1
    buildingTimer = 0,1
    buildingChronos = 0
    buildingAngle = 0
    gameOver = false ---- metre que quand ses true sa change la scene
end

function loadBuilding2()
    building2 = love.graphics.newImage("assets/building.png")
    building2_x = math.random(0,800) --- random position
    building2_y = -400
    building2_w = building:getWidth()
    building2_h = building:getHeight()
    building2Scale_X = 1
    building2Scale_Y = 1
    building2Timer = 0,1
    building2Chronos = 0
    building2Angle = 0
    gameOver = false ---- metre que quand ses true sa change la scene
end

---------------------------------------------------update----------------

function updateBuilding(dt)
    if buildingChronos > buildingTimer then  
        building_y = building_y + 3  
        buildingChronos = 0
    end

   buildingChronos = buildingChronos + dt
   ---- colider du building 
   buildingCollider_x = building_x + 80
   buildingCollider_xneg = building_x - 50
   buildingCollider_y = building_y + 80
   buildingCollider_yneg = building_y - 75
end

function updateBuilding2(dt)
    if building2Chronos > building2Timer then
        building2_y = building2_y + 3   
        building2Chronos = 0
    end
    
   building2Chronos = building2Chronos + dt
   ---- colider du building 
   building2Collider_x = building2_x + 80
   building2Collider_xneg = building2_x - 50
   building2Collider_y = building2_y + 80
   building2Collider_yneg = building2_y - 75
end

---------------------------------Draw---------------------------



function drawBuilding()
    love.graphics.draw(building,building_x,building_y , deg2rad * buildingAngle,buildingScale_X ,buildingScale_Y ,(building_w / 2), (building_h / 2))
end
function drawBuilding2()
    love.graphics.draw(building2,building2_x,building2_y , deg2rad * building2Angle,building2Scale_X ,building2Scale_Y,(building2_w / 2), (building2_h / 2))
end