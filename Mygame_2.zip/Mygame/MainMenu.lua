button_Height = 64
function newButton(text, fn)
    return { 
        text = text, 
        fn = fn,
        now = false,
        last = false
    }
end

buttons = {}
function MainMenuLoad()
    MenuFont = love.graphics.newFont(32)
    game_state = 1

    --menu button
    table.insert(buttons, newButton(
        "Start Game",
        function() 
            game_state = game_state + 1 
        end))

    table.insert(buttons, newButton(
        "Exit", 
        function()
           love.event.quit(0) 
        end))
end

function load_backgrounds()
    background_image = love.graphics.newImage("assets/Background.jpg")
end


function menuUpdate(dt)
    gameFont = love.graphics.newFont("assets/gamer.ttf", 40)
    screen_w = love.graphics.getWidth()
    screen_h = love.graphics.getHeight()
end


function menuDraw(dt)
    load_backgrounds()
    ----menu button---
    button_width = screen_w * (1/3)
    Space_Between_Button = 16

    total_Button_Height = (button_Height + Space_Between_Button) * #buttons
    cursor_y = 0
    
    for i, buttons in ipairs(buttons) do
        buttons.last = buttons.now
        ButtonX = (screen_w * 0.5) - (button_width * 0.5)
        ButtonY = (screen_h * 0.5) - (total_Button_Height * 0.5) + cursor_y
        
        color = {0.4, 0.4, 0.4, 1.0}
        mX, mY = love.mouse.getPosition()

        mousOnButton = mX > ButtonX and mX < ButtonX + button_width and
                       mY > ButtonY and mY < ButtonY + button_Height

        if mousOnButton then
            color = {0.8, 0.8, 0.8, 1}
        end

        buttons.now = love.mouse.isDown(1)
        if buttons.now and not buttons.last and mousOnButton then
            buttons.fn()
        end
        
        love.graphics.setColor(unpack(color))
        love.graphics.rectangle("fill", ButtonX, ButtonY, button_width, button_Height)
        
        love.graphics.setColor(0, 0, 0, 1)
        love.graphics.print(buttons.text, MenuFont, ButtonX, ButtonY)

        cursor_y = cursor_y + (button_Height + Space_Between_Button)
    end
end

function draw_backgrounds()
    love.graphics.draw(background_image, 0, 0)
end
