function love.load()
    loadPoulpe()
    loadAncre()
    loadAncre2()
    loadAncre3()
    loadAncre4()
    loadAncreRespawnVariable()
end

-------------------------------------------------Load------------------------------------

function loadPoulpe()
    deg2rad = 0.0174533 
    poulpeAngle = 0
    screen_w, screen_h, _  = love.window.getMode()
    poulpe = love.graphics.newImage("assets/avionForPoulp .png")
    poulpe_x = 400
    poulpe_y = screen_h -500
    poulpe_w = avion:getWidth()
    poulpe_h = avion:getHeight()
    timer = 0,1
    chronos = 0
    poulpeScale_X = 0.3
    poulpeScale_Y = 0.3
    poulpeDirection = true
end

function loadAncreRespawnVariable()
    AncreTimer = 0
    firsTime = true
    moreDificulty = false
    firsTime3 = true
    moreDificulty3 = false
    firsTime4 = true
    moreDificulty4 = false
end

function loadAncre()
    ancre = love.graphics.newImage("assets/ancre.png")
    ancre_x = poulpe_x --- poulpe position
    ancre_y = poulpe_y
    ancre_w = ancre:getWidth()
    ancre_h = ancre:getHeight()
    ancreScale_X = 0.1
    ancreScale_Y = 0.1
    timer = 0,1
    chronos = 0
    ancreAngle = 0
    gameOver = false ---- metre que quand ses true sa change la scene
end

function loadAncre2()
    ancre2 = love.graphics.newImage("assets/ancre.png")
    ancre2_x = poulpe_x--- poulpe position
    ancre2_y = poulpe_y
    ancre2_w = ancre:getWidth()
    ancre2_h = ancre:getHeight()
    ancreScale2_X = 0.1
    ancreScale2_Y = 0.1
    timer = 0,1
    chronos = 0
    ancre2Angle = 0
    gameOver = false ---- metre que quand ses true sa change la scene
end

function loadAncre3()
    ancre3 = love.graphics.newImage("assets/ancre.png")
    ancre3_x = poulpe_x --- poulpe position
    ancre3_y = poulpe_y
    ancre3_w = ancre:getWidth()
    ancre3_h = ancre:getHeight()
    ancreScale3_X = 0.1
    ancreScale3_Y = 0.1
    timer = 0,1
    chronos = 0
    ancre3Angle = 0
    gameOver = false ---- metre que quand ses true sa change la scene
end

function loadAncre4()
    ancre4 = love.graphics.newImage("assets/ancre.png")
    ancre4_x = poulpe_x --- poulpe position
    ancre4_y = poulpe_y
    ancre4_w = ancre:getWidth()
    ancre4_h = ancre:getHeight()
    ancreScale4_X = 0.1
    ancreScale4_Y = 0.1
    timer = 0,1
    chronos = 0
    ancre4Angle = 0
    gameOver = false ---- metre que quand ses true sa change la scene
end

------------------------------------------------Update-----------------------------

function updatePoulpe()

    if poulpeDirection == true then
          poulpe_x = poulpe_x +1
    end
    if poulpeDirection == false then
        poulpe_x = poulpe_x -1
    end
    if poulpe_x > 800 then
        poulpeDirection = false
    end
    if poulpe_x < 80 then
        poulpeDirection = true
    end

end

function updateAncre(dt)
     
    if chronos > timer then  
        ancre_y = ancre_y + 3
        chronos = 0
    end

    chronos = chronos + dt
   ---- colider de l'ancre
    ancreCollider_x = ancre_x + 10
    ancreCollider_xneg = ancre_x - 10
    ancreCollider_y = ancre_y + 10
    ancreCollider_yneg = ancre_y - 10   
end

function updateAncre2(dt)
    
    if chronos > timer then     
        ancre2_y = ancre2_y + 3
        chronos = 0
    end

    chronos = chronos + dt
   ---- colider de l'ancre
    ancreCollider2_x = ancre2_x + 10
    ancreCollider2_xneg = ancre2_x - 10
    ancreCollider2_y = ancre2_y + 10
    ancreCollider2_yneg = ancre2_y - 10 
end

function updateAncre3(dt)
    
    if chronos > timer then      
        ancre3_y = ancre3_y + 3
        chronos = 0
    end

    chronos = chronos + dt
   ---- colider de l'ancre
    ancreCollider3_x = ancre3_x + 10
    ancreCollider3_xneg = ancre3_x - 10
    ancreCollider3_y = ancre3_y + 10
    ancreCollider3_yneg = ancre3_y - 10
end

function updateAncre4(dt)
    
    if chronos > timer then      
        ancre4_y = ancre4_y + 3
        chronos = 0
    end

    chronos = chronos + dt
   ---- colider de l'ancre
    ancreCollider4_x = ancre4_x + 10
    ancreCollider4_xneg = ancre4_x - 10
    ancreCollider4_y = ancre4_y + 10
    ancreCollider4_yneg = ancre4_y - 10  
end

--------------------------------draw---------------------


function drawAncre()   
    love.graphics.draw(ancre,ancre_x,ancre_y , deg2rad * ancreAngle,ancreScale_X,ancreScale_Y,(ancre_w / 2), (ancre_h / 2))
end

function drawAncre2()   
    love.graphics.draw(ancre2,ancre2_x,ancre2_y , deg2rad * ancre2Angle,ancreScale2_X,ancreScale2_Y,(ancre2_w / 2), (ancre2_h / 2))
end

function drawAncre3()   
    love.graphics.draw(ancre3,ancre3_x,ancre3_y , deg2rad * ancre3Angle,ancreScale3_X,ancreScale3_Y,(ancre3_w / 2), (ancre3_h / 2))
end

function drawAncre4()  
    love.graphics.draw(ancre4,ancre4_x,ancre4_y , deg2rad * ancre4Angle,ancreScale4_X,ancreScale4_Y,(ancre4_w / 2), (ancre4_h / 2))
end

function drawPoulpe()
    love.graphics.draw(poulpe,poulpe_x,poulpe_y , deg2rad * poulpeAngle,poulpeScale_X,poulpeScale_Y,(poulpe_w / 2), (poulpe_h / 2))
end