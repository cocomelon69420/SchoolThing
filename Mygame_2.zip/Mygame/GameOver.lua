
function love.load()
    Load_Game_Over()
end

------------------- LOAD FUNCTIONS -------------------------------------

function Load_Game_Over()
    GameOver_Background = love.graphics.newImage("assets/YouDead.jpg")
end

------------------- UPDATE FUNCTIONS ----------------------------------


function updateGameOver()
    if dead == true then
        game_state = 3
    end
end

-------------------- DRAW FUNCTIONS -----------------------------------

function Draw_Game_Over()
    love.graphics.draw(GameOver_Background, 0, 0, 0, 0.8, 0.95)
    love.graphics.setFont(gameFont)
end
