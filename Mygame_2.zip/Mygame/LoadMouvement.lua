function love.load()
    loadAvion()
end

function loadAvion()
    --- call variable
    deg2rad = 0.0174533 
    avionAngle = 0
    screen_w, screen_h, _  = love.window.getMode()
    avion = love.graphics.newImage("assets/avion.png")
    avion_x = 400
    avion_y = screen_h - 80
    avion_w = avion:getWidth()
    avion_h = avion:getHeight()
    timer = 0,1
    chronos = 0
    avionScale_X = 0.1
    avionScale_Y = 0.1

end


function updateAvion(dt) 
    --- permet de deplacer l'avion a une vitesse sur le temp
    if chronos > timer then
        if avion_x  < love.mouse.getX()  then
         avion_x  = avion_x + 3
         avionAngle = 45 --- rotate avion
        end
        if avion_x > love.mouse.getX()  then
         avion_x  = avion_x - 3
         avionAngle = -45 -- rotate avion
      
        end
        if avion_x  + 3 > love.mouse.getX()  and avion_x -3 < love.mouse.getX()  then
            
         avionAngle = 0 -- rotate avion
         
        end
       
        chronos = 0
        ------ si jamais on a besoin d'un collider pour l'avion 
        collider_x = avion_x + 10
        collider_xneg = avion_x - 10
        collider_y = avion_y + 10
        collider_yneg = avion_y - 10  
    end
    chronos = chronos + dt
end


function drawAvion()
    love.graphics.draw(avion,avion_x,avion_y , deg2rad * avionAngle,avionScale_X,avionScale_Y,(avion_w / 2), (avion_h / 2))
end