------------------------Game Jame (Simon Tousignant/ Étienne Bérubé/ Zachary Lefebvre)
require("MainMenu")
require("GameOver")
require("LoadMouvement")
require("Poulpes")
require("Building")

function love.load()
    game_state = 1
    dead = false
    screen_w = love.graphics.getWidth()
    screen_h = love.graphics.getHeight()
    --love.mouse.setVisible(false)

    if game_state == 1 then
        load_backgrounds()
        MainMenuLoad()

    elseif game_state == 2 then
        loveLoad()

    elseif game_state == 3 then
        if dead == true then
           load_backgroundGameFail()
        else
           load_backgroundWin()
        end
    end

end


------------------- LOAD FUNCTIONS -------------------------------------

function loadMusic()
    music_audio = love.audio.newSource("assets/Sky Fighters.mp3", "static")
end

function loadGameTimer()
    GameTimer = 1
    GameChronos = 200
end

function load_background()
    
    background_image = love.graphics.newImage("assets/nuage.png")

end

------------------- UPDATE FUNCTIONS ----------------------------------

function love.update(dt)
    
    if game_state == 1 then
        menuUpdate(dt)
        
        
    elseif game_state == 2 then
        loveUpdate(dt)
        loveLoad()
        
    elseif game_state == 3 then
        if dead == true then
            load_backgroundGameFail()
        else
            load_backgroundWin()
        end
    end
    
end

function musicUpdate()
    
    if gameOver == false then
        love.audio.play(music_audio)
        love.audio.setVolume(100)
    else
        love.audio.stop()
        love.audio.setVolume(0) 
    end
end

function loveLoad()
    loadAvion()
    collision()
    MainMenuLoad()
    load_background()    
    loadMusic()
    loadGameTimer()
    math.randomseed(os.time())
    loadPoulpe()
    loadAncre()
    loadAncre2()
    loadAncre3()
    loadAncre4()
    loadAncreRespawnVariable()
    loadBuilding()
    loadBuilding2()
end

function drawGame()
    drawAvion()
    draw_background()
    drawAncre()
    drawAncre2()
    drawAncre3()
    drawAncre4()
    drawGameChronos()
    drawBuilding()
    drawBuilding2()
    drawPoulpe()
    Draw_Game_Over()
end

function loveUpdate(dt)
    loadAvion()
    updateAvion(dt)
    collision()
    updateGameChronos(dt)
    musicUpdate()
    updateAncre(dt)
    updateAncre2(dt)
    updateAncre3(dt)
    updateAncre4(dt)
    updatePoulpe(dt)
    updateBuilding(dt)
    updateBuilding2(dt)
    updateGameOver()
end

function updateGameChronos(dt)
    GameTimer = GameTimer * dt
    if GameTimer >  1 then
        GameChronos = GameChronos - 1      
        GameTimer = 0
    end
   
    if GameChronos <= 0  then
        GameChronos = 0
        game_state = 3 ---- changer la scene pour la scene win
        print("changer pour la scene win")    
    end
end

-------------------- DRAW FUNCTIONS -----------------------------------


function love.draw()
    if game_state == 1 then
        menuDraw(dt)
    
    elseif game_state == 2 then    
        drawGame()

    elseif game_state == 3 then
        if dead == true then
            draw_backgroundGameFail()
            drawEndGame()
            
        else
            draw_backgroundWin()
        end
    end
    
end

function draw_background()

    love.graphics.draw(background_image, 0, 0, 0, 1,1)

end


---------------------------------------Collision-------------------------
function collision()
    
    if building_y > avion_y + 100 then
        building_y = -10
        building_x = math.random(0,800)
    end 
    if building2_y > avion_y + 100 then
        building2_y = -10
        building2_x = math.random(0,800)
    end 
  --- resset sa position en a la position du poulpe
    if ancre_y > avion_y + 100 then
        
        ancre_x = poulpe_x -40--- poulpe position
        ancre_y = poulpe_y
        
    end
    if ancre2_y > avion_y + 100 then
        
        ancre2_x = poulpe_x -40--- poulpe position
        ancre2_y = poulpe_y

    end
    if ancre3_y > avion_y + 100 then
        
        ancre3_x = poulpe_x -40--- poulpe position
        ancre3_y = poulpe_y

    end
    if ancre4_y > avion_y + 100 then
        
        ancre4_x = poulpe_x -40--- poulpe position
        ancre4_y = poulpe_y

    end

    if ancre_y > avion_y - 200 then
        
       moreDificulty = true
        
    end
    if ancre_y > avion_y - 300 then
        
        moreDificulty3 = true
         
     end
     if ancre_y > avion_y - 400 then
        
        moreDificulty4 = true
         
     end
    if moreDificulty == true  then
        if firsTime == true then
        
            ancre2_x = poulpe_x  -40--- poulpe position
            ancre2_y = poulpe_y
            moreDificulty = false
            firsTime = false
        end
    end
    if moreDificulty3 == true  then
        if firsTime3 == true then
        
            ancre3_x = poulpe_x  -40--- poulpe position
            ancre3_y = poulpe_y
            moreDificulty3 = false
            firsTime3 = false
        end
    end
    if moreDificulty4 == true  then
        if firsTime4 == true then
        
            ancre4_x = poulpe_x  -40--- poulpe position
            ancre4_y = poulpe_y
            moreDificulty4 = false
            firsTime4 = false
        end
    end

    if buildingCollider_x > collider_xneg and buildingCollider_xneg < collider_x and buildingCollider_y > collider_yneg and buildingCollider_yneg < collider_y then
        print(" load secene game over") ---- a enlever plus tard
        dead = true
        game_state = 3

    end

    if building2Collider_x > collider_xneg and building2Collider_xneg < collider_x and building2Collider_y > collider_yneg and building2Collider_yneg < collider_y then
        print(" load secene game over") ---- a enlever plus tard
        game_state = 3

         dead = true
    end

    if ancreCollider_x > collider_xneg and ancreCollider_xneg < collider_x and ancreCollider_y > collider_yneg and ancreCollider_yneg < collider_y then
        print(" load secene game over") ---- a enlever plus tard
        game_state = 3
        dead = true
    end

    if ancreCollider2_x > collider_xneg and ancreCollider2_xneg < collider_x and ancreCollider2_y > collider_yneg and ancreCollider2_yneg < collider_y then
        print(" load secene game over") ---- a enlever plus tard
        game_state = 3
        dead = true
    end

    if ancreCollider3_x > collider_xneg and ancreCollider3_xneg < collider_x and ancreCollider3_y > collider_yneg and ancreCollider3_yneg < collider_y then
        print(" load secene game over") ---- a enlever plus tard
        game_state = 3
        dead = true
    end

    if ancreCollider4_x > collider_xneg and ancreCollider4_xneg < collider_x and ancreCollider4_y > collider_yneg and ancreCollider4_yneg < collider_y then
        print(" load secene game over") ---- a enlever plus tard
        game_state = 3
        dead = true
    end
 
end