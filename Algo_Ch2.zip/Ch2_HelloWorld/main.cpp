#include <iostream>  // Library for input/output stream

/// <summary>
/// This the entry point for the program.
/// </summary>
/// <returns> 0 = end with success. </returns>
int main()
{
	// Show 'Hello World' in the console.
	std::cout << "Hello World!" << std::endl;

	// Wait for user input to prevent the console to close
	system("pause");

	return 0;
}

