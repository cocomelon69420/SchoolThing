#include <iostream>  // Library for input/output stream

using namespace std; // include the std namespace for this file

/// <summary>
/// This the entry point for the program.
/// </summary>
/// <returns> 0 = end with success. </returns>
int main()
{
	// Declare two variables of type float.
	float tata = 3.5f;
	float toto = 2.5f;
	cout << "tata: " << tata << "\ntoto: " << toto << "\n----------------\n";

	system("pause");
	cout << endl;

	// Assign 3.0f to tata and make toto equal to toto + tata
	tata = 3.0f;
	toto = toto + tata;
	cout << "tata: " << tata << "\ntoto: " << toto << "\n----------------\n";

	system("pause");
	cout << endl;

	// Assign a pair and impair numbers to variable and modulo them by 2. If the remains is 0, it is a multiple of 2.
	tata = 6.5f;
	toto = 5.5f;
	cout << "tata is pair? " << (int)tata % 2 << "\ntoto is pair? " << (int)toto % 2 << "\n----------------\n";

	system("pause");
	cout << endl;

	// Division 6.5 by 5.5. Where's the remainder go? Trunked? Remember : Int = Integer = Entier
	int dividedInt = (int)(tata / toto);
	cout << "int = tata / toto: " << dividedInt << "\n----------------\n";

	system("pause");
	cout << endl;

	// Division 6.5 by 5.5.
	float dividedFloat = tata / toto;
	cout << "float = tata / toto: " << dividedFloat << "\n----------------\n";

	system("pause");

	return 0;
}
