#include <iostream>  // Library for input/output stream

using namespace std; // include the std namespace for this file

/// <summary>
/// This the entry point for the program.
/// </summary>
/// <returns> 0 = end with success. </returns>
int main()
{
	// Declare a variable to contain the user's answer
	char name[50];
	cout << "Enter your name: ";

	// Wait for the user input
	cin >> name;
	cout << "Hello, " << name << endl;

	// Wait the user input to end the program
	system("pause");

	return 0;
}
