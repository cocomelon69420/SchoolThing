#include <iostream>  // Library for input/output stream

using namespace std; // include the std namespace for this file

/// <summary>
/// This the entry point for the program.
/// </summary>
/// <returns> 0 = end with success. </returns>
int main()
{
	// Declare two variables of type int, leave one unassigned.
	int tata; 
	int toto = 50;
	cout << "tata: " << tata << "\ntoto: " << toto << "\n----------------\n";

	system("pause");

	// Assign 3 to tata and make toto equal to toto + tata
	tata = 3;
	toto = toto + tata;
	cout << "tata: " << tata << "\ntoto: " << toto << "\n----------------\n";

	system("pause");

	// Assign a pair and impair numbers to variable and modulo them by 2. If the remains is 0, it is a multiple of 2.
	tata = 6;
	toto = 5;
	cout << "tata is pair? " << tata % 2 << "\ntoto is pair? " << toto % 2 << "\n----------------\n";

	system("pause");

	// Division 6 by 5. Where's the remainder go? Trunked? Remember : Int = Integer = Entier
	int divided = tata / toto;
	cout << "tata / toto: " << divided << "\n----------------\n";

	system("pause");

	// Division5 by 6.
	divided = toto / tata;
	cout << "toto / tata: " << divided << "\n----------------\n";

	system("pause");

	// Division by zero??
	cout << "tata / 0" << tata / 0 << "\n----------------\n";

	system("pause");

	return 0;
}
