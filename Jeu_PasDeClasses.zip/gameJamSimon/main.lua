button_Height = 64
function newButton(text, fn)
    return { 
        text = text, 
        fn = fn,
        now = false,
        last = false
    }
end
function love.load()
    gameState = 1
    MainMenuLoad()
    loadMusic()
    loadGameTimer()
    loadAncreRespawnVariable()
    load_background()
    load_backgroundGameFail()
    load_backgroundWin()
    --load_backgroundMenu()
    loadAvion() --transferé sa dans le load
    loadPoulpe()
    loadAncre()
    loadAncre2()
    loadAncre3()
    loadAncre4()
    math.randomseed(os.time())
    loadBuilding()
    loadBuilding2()
    
end
function love.update(dt)
    if (gameState == 1)then
        menuUpdate(dt)
    end
    if (gameState == 2)then
       updateGameChronos(dt)
       musicUpdate()
       updateAncre(dt)
       updateAncre2(dt)
       updateAncre3(dt)
       updateAncre4(dt)
       updateAvion(dt)---transferé sa dans le update
       updatePoulpe(dt)
       updateBuilding(dt)
       updateBuilding2(dt)
       collision()
    end
    if (gameState == 3)then
        if love.keyboard.isDown("return") then
            gameState = 1
        end
    end
    if (gameState == 4)then
        if love.keyboard.isDown("return") then
            gameState = 1
        end
    end
end
function love.draw()
    if (gameState == 1)then
        menuDraw(dt)
    end
    
    if (gameState == 2)then
      draw_background()
      drawAvion() --- transferé sa dans le draw
      drawAncre()
      drawAncre2()
      drawAncre3()
      drawAncre4()
      drawGameChronos()
      drawBuilding()
      drawBuilding2()
      drawPoulpe()
    end
    if (gameState == 3)then
        draw_backgroundGameFail()
    end
    if (gameState == 4)then
        draw_backgroundWin()
    end
end
buttons = {}
function MainMenuLoad()
    MenuFont = love.graphics.newFont(32)
    --menu button
    table.insert(buttons, newButton(
        "Start Game",
        function() 
            gameState = 2
        end))

    table.insert(buttons, newButton(
        "Exit", 
        function()
           love.event.quit(0) 
        end))
end

function menuDraw(dt)
    ----menu button---
    button_width = screen_w * (1/3)
    Space_Between_Button = 16

    total_Button_Height = (button_Height + Space_Between_Button) * #buttons
    cursor_y = 0
    
    for i, buttons in ipairs(buttons) do
        buttons.last = buttons.now
        ButtonX = (screen_w * 0.5) - (button_width * 0.5)
        ButtonY = (screen_h * 0.5) - (total_Button_Height * 0.5) + cursor_y
        
        color = {0.4, 0.4, 0.4, 1.0}
        mX, mY = love.mouse.getPosition()

        mousOnButton = mX > ButtonX and mX < ButtonX + button_width and
                       mY > ButtonY and mY < ButtonY + button_Height

        if mousOnButton then
            color = {0.8, 0.8, 0.8, 1}
        end

        buttons.now = love.mouse.isDown(1)
        if buttons.now and not buttons.last and mousOnButton then
            buttons.fn()
        end
        
        love.graphics.setColor(unpack(color))
        love.graphics.rectangle("fill", ButtonX, ButtonY, button_width, button_Height)
        
        love.graphics.setColor(0, 0, 0, 1)
        love.graphics.print(buttons.text, MenuFont, ButtonX, ButtonY)

        cursor_y = cursor_y + (button_Height + Space_Between_Button)
    end
end

function menuUpdate(dt)
    gameFont = love.graphics.newFont(40)
    screen_w = love.graphics.getWidth()
    screen_h = love.graphics.getHeight()
end

function loadBuilding()
    building = love.graphics.newImage("assets/building (3).png")
    building_x = math.random(0,800) --- random position
    building_y = 0
    building_w = building:getWidth()
    building_h = building:getHeight()
    buildingScale_X = 1
    buildingScale_Y = 1
    buildingTimer = 0,1
    buildingChronos = 0
    buildingAngle = 0
    gameOver = false ---- metre que quand ses true sa change la scene
end
function loadBuilding2()
    building2 = love.graphics.newImage("assets/building (3).png")
    building2_x = math.random(0,800) --- random position
    building2_y = -400
    building2_w = building:getWidth()
    building2_h = building:getHeight()
    building2Scale_X = 1
    building2Scale_Y = 1
    building2Timer = 0,1
    building2Chronos = 0
    building2Angle = 0
    gameOver = false ---- metre que quand ses true sa change la scene
end
function loadMusic()
    music_audio = love.audio.newSource("assets/Sky Fighters.mp3", "static")
end
function loadGameTimer()
    GameTimer = 0
    GameChronos = 200
end
function loadAncreRespawnVariable()
    AncreTimer = 0
    firsTime = true
    moreDificulty = false
    firsTime3 = true
    moreDificulty3 = false
    firsTime4 = true
    moreDificulty4 = false
end
function loadAncre()
    ancre = love.graphics.newImage("assets/ancre.png")
    ancre_x = poulpe_x --- poulpe position
    ancre_y = poulpe_y
    ancre_w = ancre:getWidth()
    ancre_h = ancre:getHeight()
    ancreScale_X = 0.1
    ancreScale_Y = 0.1
    timer = 0,1
    chronos = 0
    ancreAngle = 0
    gameOver = false ---- metre que quand ses true sa change la scene


 
end
function loadAncre2()
    ancre2 = love.graphics.newImage("assets/ancre.png")
    ancre2_x = poulpe_x--- poulpe position
    ancre2_y = poulpe_y
    ancre2_w = ancre:getWidth()
    ancre2_h = ancre:getHeight()
    ancreScale2_X = 0.1
    ancreScale2_Y = 0.1
    timer = 0,1
    chronos = 0
    ancre2Angle = 0
    gameOver = false ---- metre que quand ses true sa change la scene


 
end
function loadAncre3()
    ancre3 = love.graphics.newImage("assets/ancre.png")
    ancre3_x = poulpe_x --- poulpe position
    ancre3_y = poulpe_y
    ancre3_w = ancre:getWidth()
    ancre3_h = ancre:getHeight()
    ancreScale3_X = 0.1
    ancreScale3_Y = 0.1
    timer = 0,1
    chronos = 0
    ancre3Angle = 0
    gameOver = false ---- metre que quand ses true sa change la scene


 
end
function loadAncre4()
    ancre4 = love.graphics.newImage("assets/ancre.png")
    ancre4_x = poulpe_x --- poulpe position
    ancre4_y = poulpe_y
    ancre4_w = ancre:getWidth()
    ancre4_h = ancre:getHeight()
    ancreScale4_X = 0.1
    ancreScale4_Y = 0.1
    timer = 0,1
    chronos = 0
    ancre4Angle = 0
    gameOver = false ---- metre que quand ses true sa change la scene


 
end
function load_background()

    background_image = love.graphics.newImage("assets/nuage.png")

end
function load_backgroundGameFail()
    backgroundGameFail_image = love.graphics.newImage("assets/YouDead.jpg")
end
function load_backgroundMenu()
   
    backgroundMenu_image = love.graphics.newImage("assets/menu2.jpg")
end
function load_backgroundWin()
    backgroundWin_image = love.graphics.newImage("assets/menuWin2.png")
end
function draw_background()

    love.graphics.draw(background_image, 0, 0, 0, 1, 1)

end
function draw_backgroundMenu()
 
    love.graphics.draw(backgroundMenu_image, 0, 0, 0, 0.8, 0.6)
end
function draw_backgroundWin()
    love.graphics.draw(backgroundWin_image, 0, 0, 0, 1, 1.1)
end
function draw_backgroundGameFail()
    love.graphics.draw(backgroundGameFail_image, 0, 0, 0, 0.6, 0.6)
end
function drawBuilding()
    love.graphics.draw(building,building_x,building_y , deg2rad * buildingAngle,buildingScale_X ,buildingScale_Y ,(building_w / 2), (building_h / 2))
end
function drawBuilding2()
    love.graphics.draw(building2,building2_x,building2_y , deg2rad * building2Angle,building2Scale_X ,building2Scale_Y,(building2_w / 2), (building2_h / 2))
end
function loadAvion()
    --- call variable
    deg2rad = 0.0174533 
    avionAngle = 0
    screen_w, screen_h, _  = love.window.getMode()
    avion = love.graphics.newImage("assets/avion.png")
   avion_x = 400
    avion_y = screen_h - 80
    avion_w = avion:getWidth()
    avion_h = avion:getHeight()
    timer = 0,1
    chronos = 0
    avionScale_X = 0.1
    avionScale_Y = 0.1

end
function loadPoulpe()
    deg2rad = 0.0174533 
    poulpeAngle = 0
    screen_w, screen_h, _  = love.window.getMode()
    poulpe = love.graphics.newImage("assets/avionForPoulp .png")
    poulpe_x = 400
    poulpe_y = screen_h -500
    poulpe_w = avion:getWidth()
    poulpe_h = avion:getHeight()
    timer = 0,1
    chronos = 0
    poulpeScale_X = 0.3
    poulpeScale_Y = 0.3
    poulpeDirection = true
end
function drawGameChronos()
    love.graphics.setColor(0, 0, 0)
    text = love.graphics.print("vous devez survivre durents ce laps de temp: " .. GameChronos, 225, 5)
    love.graphics.setColor(255, 255, 255)
end

function drawAncre()
   
    love.graphics.draw(ancre,ancre_x,ancre_y , deg2rad * ancreAngle,ancreScale_X,ancreScale_Y,(ancre_w / 2), (ancre_h / 2))

end
function drawAncre2()
   
    love.graphics.draw(ancre2,ancre2_x,ancre2_y , deg2rad * ancre2Angle,ancreScale2_X,ancreScale2_Y,(ancre2_w / 2), (ancre2_h / 2))

end
function drawAncre3()
   
    love.graphics.draw(ancre3,ancre3_x,ancre3_y , deg2rad * ancre3Angle,ancreScale3_X,ancreScale3_Y,(ancre3_w / 2), (ancre3_h / 2))

end
function drawAncre4()
   
    love.graphics.draw(ancre4,ancre4_x,ancre4_y , deg2rad * ancre4Angle,ancreScale4_X,ancreScale4_Y,(ancre4_w / 2), (ancre4_h / 2))

end
function drawAvion()
    --- love.graphics.draw(image,posX,posY,rotation(radian),scaleX,scaleY,offsetX,offsetY)-- dessine l'avion
    love.graphics.draw(avion,avion_x,avion_y , deg2rad * avionAngle,avionScale_X,avionScale_Y,(avion_w / 2), (avion_h / 2))
end
function drawPoulpe()
    love.graphics.draw(poulpe,poulpe_x,poulpe_y , deg2rad * poulpeAngle,poulpeScale_X,poulpeScale_Y,(poulpe_w / 2), (poulpe_h / 2))
end
function musicUpdate()
    -- Ajoutez ici le chargement de l'ensemble des sons et musique que vous voulez jouer
    if gameOver == false then
    love.audio.play(music_audio)
    love.audio.setVolume(100)
    else
     love.audio.stop()
     love.audio.setVolume(0) 
    end

end
function updateGameChronos(dt)
    GameTimer = GameTimer +1 * dt
    if GameTimer >  1 then
        GameChronos = GameChronos - 1
       
        GameTimer = 0
    end
   
    if GameChronos <= 0  then
        GameChronos = 0
        gameState = 4 ---- changer la scene pour la scene win
        print("changer pour la scene win")
        
    end
end
function updateBuilding(dt)
    if buildingChronos > buildingTimer then
        
        building_y = building_y + 3
        
        buildingChronos = 0
    end
  buildingChronos = buildingChronos + dt
   ---- colider du building 
   buildingCollider_x = building_x + 80
   buildingCollider_xneg = building_x - 50
   buildingCollider_y = building_y + 80
   buildingCollider_yneg = building_y - 75
end
function updateBuilding2(dt)
    if building2Chronos > building2Timer then
        
        building2_y = building2_y + 3
        
        building2Chronos = 0
    end
  building2Chronos = building2Chronos + dt
   ---- colider du building 
   building2Collider_x = building2_x + 80
   building2Collider_xneg = building2_x - 50
   building2Collider_y = building2_y + 80
   building2Collider_yneg = building2_y - 75
end
function updateAncre(dt)
     
    if chronos > timer then
        
        ancre_y = ancre_y + 3
        
        chronos = 0
    end
  chronos = chronos + dt
   ---- colider de l'ancre
    ancreCollider_x = ancre_x + 10
    ancreCollider_xneg = ancre_x - 10
    ancreCollider_y = ancre_y + 10
    ancreCollider_yneg = ancre_y - 10

    
end
function updateAncre2(dt)
    
    if chronos > timer then
        
       
        ancre2_y = ancre2_y + 3
        chronos = 0
    end
  chronos = chronos + dt
   ---- colider de l'ancre
    ancreCollider2_x = ancre2_x + 10
    ancreCollider2_xneg = ancre2_x - 10
    ancreCollider2_y = ancre2_y + 10
    ancreCollider2_yneg = ancre2_y - 10

    
end
function updateAncre3(dt)
    
    if chronos > timer then
        
       
        ancre3_y = ancre3_y + 3
        chronos = 0
    end
  chronos = chronos + dt
   ---- colider de l'ancre
    ancreCollider3_x = ancre3_x + 10
    ancreCollider3_xneg = ancre3_x - 10
    ancreCollider3_y = ancre3_y + 10
    ancreCollider3_yneg = ancre3_y - 10

    
end
function updateAncre4(dt)
    
    if chronos > timer then
        
       
        ancre4_y = ancre4_y + 3
        chronos = 0
    end
  chronos = chronos + dt
   ---- colider de l'ancre
    ancreCollider4_x = ancre4_x + 10
    ancreCollider4_xneg = ancre4_x - 10
    ancreCollider4_y = ancre4_y + 10
    ancreCollider4_yneg = ancre4_y - 10

    
end

function updateAvion(dt)
    
 --- permet de deplacer l'avion a une vitesse sur le temp
 if chronos > timer then
     if avion_x  < love.mouse.getX()  then
      avion_x  = avion_x + 3
      avionAngle = 45 --- rotate l'avion
     end
     if avion_x > love.mouse.getX()  then
      avion_x  = avion_x - 3
      avionAngle = -45 -- rotate lavion
   
     end
     if avion_x  + 3 > love.mouse.getX()  and avion_x -3 < love.mouse.getX()  then
         
      avionAngle = 0 -- rotate lavion
      
     end
    
     chronos = 0
     ------ si jamais on a besoin d'un collider pour l'avion 
     collider_x = avion_x + 10
     collider_xneg = avion_x - 10
     collider_y = avion_y + 10
     collider_yneg = avion_y - 10
  

 end
 chronos = chronos + dt
end
function updatePoulpe()

    if poulpeDirection == true then
          poulpe_x = poulpe_x +1
    end
    if poulpeDirection == false then
        poulpe_x = poulpe_x -1
    end
    if poulpe_x > 800 then
        poulpeDirection = false
    end
    if poulpe_x < 80 then
        poulpeDirection = true
    end

end
function collision()
    
    if building_y > avion_y + 100 then
        building_y = -10
        building_x = math.random(0,800)
    end 
    if building2_y > avion_y + 100 then
        building2_y = -10
        building2_x = math.random(0,800)
    end 
  --- resset sa position en a la position du poulpe
    if ancre_y > avion_y + 100 then
        
        ancre_x = poulpe_x -40--- poulpe position
        ancre_y = poulpe_y
        
    end
    if ancre2_y > avion_y + 100 then
        
        ancre2_x = poulpe_x -40--- poulpe position
        ancre2_y = poulpe_y

    end
    if ancre3_y > avion_y + 100 then
        
        ancre3_x = poulpe_x -40--- poulpe position
        ancre3_y = poulpe_y

    end
    if ancre4_y > avion_y + 100 then
        
        ancre4_x = poulpe_x -40--- poulpe position
        ancre4_y = poulpe_y

    end

    if ancre_y > avion_y - 200 then
        
       moreDificulty = true
        
    end
    if ancre_y > avion_y - 300 then
        
        moreDificulty3 = true
         
     end
     if ancre_y > avion_y - 400 then
        
        moreDificulty4 = true
         
     end
    if moreDificulty == true  then
        if firsTime == true then
        
            ancre2_x = poulpe_x  -40--- poulpe position
            ancre2_y = poulpe_y
            moreDificulty = false
            firsTime = false
        end
    end
    if moreDificulty3 == true  then
        if firsTime3 == true then
        
            ancre3_x = poulpe_x  -40--- poulpe position
            ancre3_y = poulpe_y
            moreDificulty3 = false
            firsTime3 = false
        end
    end
    if moreDificulty4 == true  then
        if firsTime4 == true then
        
            ancre4_x = poulpe_x  -40--- poulpe position
            ancre4_y = poulpe_y
            moreDificulty4 = false
            firsTime4 = false
        end
    end
    if buildingCollider_x > collider_xneg and buildingCollider_xneg < collider_x and buildingCollider_y > collider_yneg and buildingCollider_yneg < collider_y then
        print(" load secene game over") ---- a enlever plus tard
         gameState = 3
    end
    if building2Collider_x > collider_xneg and building2Collider_xneg < collider_x and building2Collider_y > collider_yneg and building2Collider_yneg < collider_y then
        print(" load secene game over") ---- a enlever plus tard
        gameState = 3
    end
   if ancreCollider_x > collider_xneg and ancreCollider_xneg < collider_x and ancreCollider_y > collider_yneg and ancreCollider_yneg < collider_y then
    print(" load secene game over") ---- a enlever plus tard
     gameState = 3
   end
     if ancreCollider2_x > collider_xneg and ancreCollider2_xneg < collider_x and ancreCollider2_y > collider_yneg and ancreCollider2_yneg < collider_y then
    print(" load secene game over") ---- a enlever plus tard
    gameState = 3
   end
   if ancreCollider3_x > collider_xneg and ancreCollider3_xneg < collider_x and ancreCollider3_y > collider_yneg and ancreCollider3_yneg < collider_y then
    print(" load secene game over") ---- a enlever plus tard
    gameState = 3
   end
   if ancreCollider4_x > collider_xneg and ancreCollider4_xneg < collider_x and ancreCollider4_y > collider_yneg and ancreCollider4_yneg < collider_y then
    print(" load secene game over") ---- a enlever plus tard
    gameState = 3
   end
 
end
