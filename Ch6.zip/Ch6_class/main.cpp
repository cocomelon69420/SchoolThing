#include <iostream>  // Library for input/output stream

using namespace std;
/// <summary>
/// Initialisation d'un tableau
/// </summary>
/// <returns></returns>

// Definition de la class Temps
class Temps
{
public:
	Temps();        // Constructeur
	void ajusterTemps(int a_Heure, int a_Minute, int a_Seconde);
	void afficherMilitaire();
	void afficherStandard();
private:
	int heure;
	int minute;
	int seconde;
};

Temps::Temps()
{
	heure = minute = seconde = 0;
}

void Temps::ajusterTemps(int a_Heure, int a_Minute, int a_Seconde)
{
	heure = (a_Heure >= 0 && a_Heure < 24) ? a_Heure : 0;
	minute = (a_Minute >= 0 && a_Minute < 60) ? a_Minute : 0;
	seconde = (a_Seconde >= 0 && a_Seconde < 60) ? a_Seconde : 0;
}

/// <summary>
/// Affichage du temps en format militaire (hh:mm)
/// </summary>
/// <param name="a_refTemps">a reference temps.</param>
void Temps::afficherMilitaire()
{
	cout << (heure < 10 ? "0" : "") << heure << ":"
		<< (minute < 10 ? "0" : "") << minute;
}

/// <summary>
/// Affichage du temps en format standard (hh:mm:ssAM/PM)
/// </summary>
/// <param name="a_refTemps">a reference temps.</param>
void Temps::afficherStandard()
{
	cout << ((heure == 0 || heure == 12) ? 12 : heure % 12)
		<< ":" << (minute < 10 ? "0" : "") << minute
		<< ":" << (seconde < 10 ? "0" : "") << seconde
		<< (heure < 12 ? "AM" : "PM");
}

int main()
{
	// Declaration de la variable temps de type Temps
	Temps temps;

	// Assignation des valeurs aux membres de la structure
	temps.ajusterTemps(16, 30, 0);

	// Affichage du temps
	cout << "Le souper aura lieu a: ";
	temps.afficherMilitaire();
	cout << ", temps militaire, \n ou a: ";
	temps.afficherStandard();
	cout << ", temps standard.\n";

	system("pause");

	return 0;
}