#ifndef MAIN
#define MAIN

int main()
{
}

#endif