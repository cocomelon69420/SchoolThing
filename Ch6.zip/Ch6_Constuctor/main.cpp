#include <iostream>  // Library for input/output stream

#include "Time.h"

using namespace std;
/// <summary>
/// Initialisation d'un tableau
/// </summary>
/// <returns></returns>
int main()
{
	Time time;
	time.afficherStandard();

	cout << endl;

	time = Time(5, 30, 0);
	time.afficherStandard();

	cout << endl; 

	time = Time(5);
	time.afficherStandard();

	cout << endl;

	time = Time(5, 59);
	time.afficherStandard();

	cout << endl;
	system("pause");

	return 0;
}