#pragma once

#ifndef PERSONNAGE
#define PERSONNAGE

#include <iostream>
#include <string>

class Character
{
public:
	Character(const std::string a_Name);
	void TakeDamage(int a_Damage);
	void Attack(Character& a_Targe, int a_Power);

private:
	int m_Hp;
	std::string m_Name;

};

#endif