#ifndef MAIN
#define MAIN

#include "Character.h"
#include "Warrior.h"
#include "Magician.h"

int main()
{
	Character character("JohnDoe");
	Warrior warrior("Rambo");
	Magician magician("Gandalf");

	character.Attack(warrior, 10);
	warrior.AttackWithHammer(magician);
	magician.CastFirebolt(warrior);
}

#endif