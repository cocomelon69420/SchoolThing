#include "Warrior.h"

Warrior::Warrior(const std::string& a_Name)
	: Character(a_Name)
{
}

Warrior::~Warrior()
{
}

void Warrior::AttackWithHammer(Character& a_Target)
{
	Attack(a_Target, 20);
}