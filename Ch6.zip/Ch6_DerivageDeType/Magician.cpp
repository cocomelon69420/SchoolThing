#include "Magician.h"

Magician::Magician(const std::string& a_Name)
	: Character(a_Name)
{
}


Magician::~Magician()
{
}

void Magician::CastFirebolt(Character& a_Target)
{
	Attack(a_Target, 30);
}
