#include "Character.h"

using namespace std;

Character::Character(const std::string a_Name)
	: m_Hp(100)
	, m_Name(a_Name)
{
}

void Character::TakeDamage(const int a_Damage) 
{
	m_Hp -= a_Damage;
}

void Character::Attack(Character& a_Target, int a_Power)
{
	a_Target.TakeDamage(a_Power);
}