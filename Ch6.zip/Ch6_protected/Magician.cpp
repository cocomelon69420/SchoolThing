#include "Magician.h"

Magician::Magician(const std::string& a_Name)
	: Character(a_Name)
{
}


Magician::~Magician()
{
}

void Magician::CastFirebolt(Character& a_Target)
{
	std::cout << m_Name << " cast a firebolt!\n";
	Attack(a_Target, 30);
}
