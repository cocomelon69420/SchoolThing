#include <iostream>  // Library for input/output stream

using namespace std;
/// <summary>
/// Initialisation d'un tableau
/// </summary>
/// <returns></returns>

// D�finition de la structure Temps
struct Temps
{
	int heure;
	int minute;
	int seconde;
};  // Bien noter le ; a la suite de la declaration

void afficherMilitaire(const Temps& a_refTemps);	// Prototype de la fonction afficherMilitaire
void afficherStandard(const Temps& a_refTemps);		// Prototype de la fonction afficherStandard

int main()
{
	// Declaration de la variable temps de type Temps
	Temps temps;

	// Assignation des valeurs aux membres de la structure
	temps.heure = 18;
	temps.minute = 30;
	temps.seconde = 0;

	// Affichage du temps
	cout << "Le souper aura lieu a: ";
	afficherMilitaire(temps);
	cout << ", temps militaire, \n ou a: ";
	afficherStandard(temps);
	cout << ", temps standard.\n";

	system("pause");

	return 0;
}

/// <summary>
/// Affichage du temps en format militaire (hh:mm)
/// </summary>
/// <param name="a_refTemps">a reference temps.</param>
void afficherMilitaire(const Temps& a_refTemps)
{
	cout << (a_refTemps.heure < 10 ? "0" : "") << a_refTemps.heure << ":"
		<< (a_refTemps.minute < 10 ? "0" : "") << a_refTemps.minute;
}

/// <summary>
/// Affichage du temps en format standard (hh:mm:ssAM/PM)
/// </summary>
/// <param name="a_refTemps">a reference temps.</param>
void afficherStandard(const Temps& a_refTemps)
{
	cout << ((a_refTemps.heure == 0 || a_refTemps.heure == 12) ? 12 : a_refTemps.heure % 12)
		<< ":" << (a_refTemps.minute < 10 ? "0" : "") << a_refTemps.minute
		<< ":" << (a_refTemps.seconde < 10 ? "0" : "") << a_refTemps.seconde
		<< (a_refTemps.heure < 12 ? "AM" : "PM");
}