#include "Warrior.h"

Warrior::Warrior(const std::string& a_Name)
	: Character(a_Name)
{
}

Warrior::~Warrior()
{
}

void Warrior::AttackWithHammer(Character& a_Target)
{
	std::cout << m_Name << " attack with a hammer!\n";
	Attack(a_Target, 20);
}