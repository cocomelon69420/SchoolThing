#pragma once

#ifndef MAGICIAN
#define MAGICIAN

#include "Character.h"

class Magician : public Character
{
public:
	Magician(const std::string& a_Name);
	~Magician();

	void CastFirebolt(Character& a_Target);

	void Greetings();

private:

};

#endif
