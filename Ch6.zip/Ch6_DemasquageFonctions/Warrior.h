#pragma once

#ifndef WARRIOR
#define WARRIOR

#include "Character.h"

class Warrior : public Character
{
public:
	Warrior(const std::string& a_Name);
	~Warrior();

	void AttackWithHammer(Character& a_Target);

private:
};

#endif

