#pragma once
class Time
{
public:
	Time();
	~Time();

	inline void ajusterTemps(int a_Heure, int a_Minute, int a_Seconde);
	void afficherMilitaire();
	void afficherStandard();
private:
	int heure;
	int minute;
	int seconde;
};

void Time::ajusterTemps(int a_Heure, int a_Minute, int a_Seconde)
{
	heure = (a_Heure >= 0 && a_Heure < 24) ? a_Heure : 0;
	minute = (a_Minute >= 0 && a_Minute < 60) ? a_Minute : 0;
	seconde = (a_Seconde >= 0 && a_Seconde < 60) ? a_Seconde : 0;
}

