#include "Time.h"
#include <iostream>

using namespace std;

Time::Time()
	: heure(0)
	, minute(0)
	, seconde(0)
{
}


Time::~Time()
{
}

/// <summary>
/// Affichage du temps en format militaire (hh:mm)
/// </summary>
/// <param name="a_refTemps">a reference temps.</param>
void Time::afficherMilitaire()
{
	cout << (heure < 10 ? "0" : "") << heure << ":"
		<< (minute < 10 ? "0" : "") << minute;
}

/// <summary>
/// Affichage du temps en format standard (hh:mm:ssAM/PM)
/// </summary>
/// <param name="a_refTemps">a reference temps.</param>
void Time::afficherStandard()
{
	cout << ((heure == 0 || heure == 12) ? 12 : heure % 12)
		<< ":" << (minute < 10 ? "0" : "") << minute
		<< ":" << (seconde < 10 ? "0" : "") << seconde
		<< (heure < 12 ? "AM" : "PM");
}

