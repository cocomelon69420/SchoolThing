#include <iostream>  // Library for input/output stream

#include "Time.h"

using namespace std;
/// <summary>
/// Initialisation d'un tableau
/// </summary>
/// <returns></returns>
int main()
{
	Time time;
	time.heure = 10;
	time.ajusterTemps(16, 30, 0);
	//time.afficherStandard();

	cout << endl;
	system("pause");

	return 0;
}